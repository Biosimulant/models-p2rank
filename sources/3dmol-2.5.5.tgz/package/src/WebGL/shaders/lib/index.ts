export * from "./basic"
export * from "./instanced"
export * from "./lambert"
export * from "./lambertdouble"
export * from "./outline"
export * from "./screen"
export * from "./screenaa"
export * from "./ringimposter"
export * from "./sphereimposter"
export * from "./sphereimposteroutline"
export * from "./sprite"
export * from "./stickimposter"
export * from "./stickimposteroutline"
export * from "./volumetric"

import { Shader } from '../ShaderType';
import { basic } from "./basic"
import { instanced } from "./instanced"
import { lambert } from "./lambert"
import { lambertdouble } from "./lambertdouble"
import { outline } from "./outline"
import { screen } from "./screen"
import { screenaa } from "./screenaa"
import { ssao } from "./ssao"
import { ringimposter } from "./ringimposter"
import { sphereimposter } from "./sphereimposter"
import { sphereimposteroutline } from "./sphereimposteroutline"
import { sprite } from "./sprite"
import { stickimposter } from "./stickimposter"
import { stickimposteroutline } from "./stickimposteroutline"
import { volumetric } from "./volumetric"
import {blur } from "./blur"

export const ShaderLib: Record<string, Shader> = {
    basic,
    blur,
    instanced,
    lambert,
    lambertdouble,
    outline,
    screen,
    screenaa,
    ssao,
    ringimposter,
    sphereimposter,
    sphereimposteroutline,
    sprite,
    stickimposter,
    stickimposteroutline,
    volumetric,
}