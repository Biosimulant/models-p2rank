export const uniforms = {}
