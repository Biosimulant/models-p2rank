import { Matrix4 } from "WebGL/math";
import { Color } from "../../../../colors";

export const uniforms = {
    opacity: { type: 'f', value: 1.0 },
    fogColor: { type: 'c', value: new Color(1.0, 1.0, 1.0) },
    fogNear: { type: 'f', value: 1.0 },
    fogFar: { type: 'f', value: 2000},
    outlineColor: { type: 'c', value: new Color(0.0, 0.0, 0.0) },
    outlineWidth: { type: 'f', value: 0.1 },
    outlinePushback: { type: 'f', value: 1.0 },
    outlineMaxPixels: { type: 'f', value: 0.0 },
    projinv: { type: 'mat4', value: [] as Matrix4[] }
}